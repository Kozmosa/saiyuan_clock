/*
 * SPDX-FileCopyrightText: 2022 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 */
#include "nvs_flash.h"
#include "esp_netif.h"
#include "protocol_examples_common.h"
#include "esp_event.h"
#include <sys/time.h>
#include <stdlib.h>
#include "string.h"
#include <sys/unistd.h>

#define CONFIG_EXAMPLE_CONNECT_WIFI 1
#define CONFIG_EXAMPLE_WIFI_SSID_PWD_FROM_STDIN 0
#define CONFIG_EXAMPLE_WIFI_SSID "YangPC"
#define CONFIG_EXAMPLE_WIFI_PASSWORD "88888888"
// i2c screen driver
#include <stdio.h>
#include "esp_log.h"
#include "driver/i2c.h"
#include "sdkconfig.h"
#include "OLEDDisplay.h"
static const char *TAG = "oled-example";

#define _I2C_NUMBER(num) I2C_NUM_##num
#define I2C_NUMBER(num) _I2C_NUMBER(num)
#define I2C_MASTER_SCL_IO CONFIG_I2C_MASTER_SCL               /*!< gpio number for I2C master clock */
#define I2C_MASTER_SDA_IO CONFIG_I2C_MASTER_SDA               /*!< gpio number for I2C master data  */
#define I2C_MASTER_NUM I2C_NUMBER(CONFIG_I2C_MASTER_PORT_NUM) /*!< I2C port number for master dev */

SemaphoreHandle_t print_mux = NULL;

void get_time(char *time_string){
    time_t now;
    char strftime_buf[64];
    struct tm timeinfo;

    time(&now);
    // 将时区设置为中国标准时间
    setenv("TZ", "CST-8", 1);
    tzset();

    localtime_r(&now, &timeinfo);
    strftime(strftime_buf, sizeof(strftime_buf), "%c", &timeinfo);
    ESP_LOGI(TAG, "The current date/time in Shanghai is: %s", strftime_buf);
    strcpy(time_string, strftime_buf);
}

static void i2c_test_task(void *arg)
{
    OLEDDisplay_t *oled = OLEDDisplay_init(I2C_MASTER_NUM,0x78,I2C_MASTER_SDA_IO,I2C_MASTER_SCL_IO);

    OLEDDisplay_fillRect(oled,7,7,18,18);
    OLEDDisplay_drawRect(oled,6,32,20,20);
    OLEDDisplay_display(oled);
    vTaskDelay(500 / portTICK_PERIOD_MS);

    char timeString[64] = {};
    get_time(timeString);

    OLEDDisplay_setTextAlignment(oled,TEXT_ALIGN_CENTER);
    OLEDDisplay_setFont(oled,ArialMT_Plain_24);
    OLEDDisplay_drawString(oled,64, 00, "Test");
    OLEDDisplay_display(oled);
    vTaskDelay(500 / portTICK_PERIOD_MS);

    OLEDDisplay_setFont(oled,ArialMT_Plain_16);
    OLEDDisplay_drawString(oled,64, 25, "Testing");
    OLEDDisplay_display(oled);
    vTaskDelay(500 / portTICK_PERIOD_MS);

    OLEDDisplay_setFont(oled,ArialMT_Plain_10);
    OLEDDisplay_drawString(oled,64, 40, timeString);
    OLEDDisplay_display(oled);

    while(1) {
        OLEDDisplay_setColor(oled,INVERSE);
        OLEDDisplay_fillRect(oled,6,6,20,20);
        OLEDDisplay_fillRect(oled,6,32,20,20);
        OLEDDisplay_display(oled);
        vTaskDelay(250 / portTICK_PERIOD_MS);
    }

    vSemaphoreDelete(print_mux);
    vTaskDelete(NULL);
}

void i2c_app_main(void)
{
    print_mux = xSemaphoreCreateMutex();
    ESP_LOGI(TAG,"Running");
    xTaskCreate(i2c_test_task, "i2c_test_task_0", 1024 * 2, (void *)0, 10, NULL);
}

extern void tcp_client(void);

void app_main(void)
{
    ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    /* This helper function configures Wi-Fi or Ethernet, as selected in menuconfig.
     * Read "Establishing Wi-Fi or Ethernet Connection" section in
     * examples/protocols/README.md for more information about this function.
     */
    ESP_ERROR_CHECK(example_connect());

    i2c_app_main();

    tcp_client();
}
