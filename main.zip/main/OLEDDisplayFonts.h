#ifndef OLEDDISPLAYFONTS_h
#define OLEDDISPLAYFONTS_h

#define PROGMEM
#include <sys/types.h>

extern const uint8_t ArialMT_Plain_10[] PROGMEM ;

extern const uint8_t ArialMT_Plain_16[] PROGMEM;
extern const uint8_t ArialMT_Plain_24[] PROGMEM;
#endif
